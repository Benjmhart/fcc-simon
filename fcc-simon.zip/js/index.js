/* 

***TO DO***

- css touchups height below certain size needs to scale everything down, height above certain size needs to scale everything up and corrcet drift.
- add gameover/clear intervals to off switch
- gameover function for strict fail and switchoff
- fail animation-sound for strict and nonstrict failures
- victory state and animation
- color adjustments on click listeners since the first color change is preventing non JS background color changes
- tempo change on turn 5, 9, and 13


*/


//SETUP

var gamestate = [];
var onOff = true;
var gamerunning=false;
var tempo = 2500;
var isStrict = false;
var playerTurn = false;
//variables used to check player choices
var playerChoices=[];
var choiceCounter=0;
var buttons={
  'ul':
  {   
    'col1': 'blue',
    'col2': 'cyan',
    'sound': new Audio('https://s3.amazonaws.com/freecodecamp/simonSound2.mp3')
 },
  'ur': 
  {
    'col1': 'green',
    'col2': 'chartreuse',
    'sound': new Audio('https://s3.amazonaws.com/freecodecamp/simonSound3.mp3')
},
  'll':{
    'col1': 'red',
    'col2': 'firebrick',
    'sound': new Audio('https://s3.amazonaws.com/freecodecamp/simonSound1.mp3')
  },
  'lr': {
    'col1': 'gold',
    'col2': 'yellow',
    'sound': new Audio('https://s3.amazonaws.com/freecodecamp/simonSound4.mp3')
  }
};
//On/ooff swich functionliy
function switchListener(callback){
  //turning off
  if(onOff===true){
  $('#countertext').css('color', 'black');
    //game reset and clear all timeouts/intervals
  }
  //turning on
  if(onOff===false){
    $('#countertext').css('color', 'red');
  }
  callback();
}
function switchCallback(){
  console.log('callback is firing');
  if(onOff===true){onOff=false;console.log(onOff);} else if(onOff===false){onOff=true;console.log(onOff);}
}
//event listener for on/off switch
$('.switch').mouseup(function(){switchListener(switchCallback);});
//listener for the start button 
$('#startbutton').mouseup(function(){
  if(onOff===true&&gamerunning===false){
    gamerunning=true;
    console.log('time for the cpu turn to start');
    // functionality to reset game in progress.
    cpuTurn(cpuRecite());
  }
});
//listener on the strict button
$('#strictbutton').mouseup(function(){
  if(isStrict===true){
    isStrict=false;
    $('#strictindicate').css('background-color', 'black');
    console.log('you turned strict mode off');
  }
  else if(isStrict===false){
    isStrict=true;
    $('#strictindicate').css('background-color', 'blue');
    console.log('you turned strict mode on');  
  }
});

// *** PLAYER TURN & button press functions ***
$('.circleButton').mousedown(function(event){
  if(onOff===true){
    
    console.log('player pushed: '+this.id);
    buttons[this.id].sound.play();
    //play sound
    if(playerTurn===true){
      playerChoices.push(this.id)
      //if wrong
      if(playerChoices[choiceCounter]!==gamestate[choiceCounter]){
        
        console.log('you flubbed it!!')
        if(isStrict===true){
          //game over  
        }
        else{
          
          playerTurn=false;
          cpuRecite();
        }
      } else {
        console.log('success!')
        choiceCounter++;
        if (choiceCounter==gamestate.length){
          cpuTurn();
        }
      }
      
    }
  }
})



// ***CPU AI functionality**&
function cpuTurn(){
  var cpuChoices=['ul', 'ur', 'll', 'lr'];
  var nextChoice=cpuChoices[Math.floor(Math.random()*cpuChoices.length)];
  gamestate.push(nextChoice);
  if(gamestate.length<10){
    $('#countertext')[0].innerHTML='0'+gamestate.length; 
  } 
  else{
    $('#countertext')[0].innerHTML=gamestate.length;
  }
  console.log('the next choice is: '+nextChoice+' the choices so far are: '+gamestate);
  cpuRecite();
}

function cpuRecite(callback){
  //iterate gamestate array, each time playing a sound and changing colors
  var currentCount=0;
  var reciteTime=setInterval(function(){
    if(currentCount===gamestate.length){
      clearInterval(reciteTime);
      playerTurn=true;
      playerChoices=[];
      choiceCounter=0;
    }
    else{
      $('#'+gamestate[currentCount]).css('background-color', buttons[gamestate[currentCount]].col2);
      console.log('logging button object from the DOM...');
      console.log($('#'+gamestate[currentCount]));
      console.log('changing color of: '+ [gamestate[currentCount]]+ ' to: '+buttons[gamestate[currentCount]].col2);
      buttons[gamestate[currentCount]].sound.play();
      setTimeout(function(){
        $('#'+gamestate[currentCount]).css('background-color', buttons[gamestate[currentCount]].col1);
        console.log('changing color of: '+ [gamestate[currentCount]]+ ' to: '+buttons[gamestate[currentCount]].col1);
        currentCount++;
      }, (tempo/1.5));;
    }
  },tempo);
}